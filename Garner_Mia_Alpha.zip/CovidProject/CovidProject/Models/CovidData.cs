﻿using System;
using System.Collections.Generic;

namespace CovidProject.Models
{
    public class CovidData
    {
        public int Cases { get; set; }

        public int Deaths { get; set; }

        public int VaccinationsCompleted { get; set; }




        
    }
}
