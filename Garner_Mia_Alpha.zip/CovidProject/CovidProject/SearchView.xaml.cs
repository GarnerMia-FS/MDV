﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace CovidProject
{
    public partial class SearchView : ContentPage
    {
        public SearchView()
        {
            InitializeComponent();

           
        }

        
    }
}
