﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace CovidProject
{
    public partial class TestingView : ContentPage
    {

        

        public TestingView()
        {
            InitializeComponent();

           
            
        }
    }
}
