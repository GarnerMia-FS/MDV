﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace CovidProject
{
    public partial class NewsView : ContentPage
    {
        public NewsView()
        {
            InitializeComponent();
        }
    }
}
